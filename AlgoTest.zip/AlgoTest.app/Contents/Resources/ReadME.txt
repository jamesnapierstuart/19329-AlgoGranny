AlgoGranny Application: Algorithmic Granular Synthesis composition

Candidate No: 19329
Studio Project
University of Sussex
MAY 2014

BUILT IN SuperCollider 3.6.6
MAC OSX VERSION 10.8.4
--------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------
AlgoGranny About:



--------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------
Install:

The Disk Image file will give the option of dragging and dropping the AlgoGranny to the users application folder:

1. Drag the AlgoGranny Analysis App into your Applications folder.
-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------

Development of this SuperCollider Standalone application was made possible from building upon Dathinaios' sc_osx_standalone template (https://github.com/dathinaios/sc_osx_standalone, last accessed 24/04/14). And running the .sh script provided with Platypus Application (http://sveinbjorn.org/platypus, last accessed 24/04/14).

Modifications had to be made to change the Scope Method to look in the new scsynth directory, and similarly synthdef libraries were re-configured.
Notes from Dathinaios' original read me regarding the Linux standalone implementation it was based upon can be found below:
-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------

# SuperCollider OSX Standalone

Modified from the linux version:
https://github.com/miguel-negrao/linuxStandalone

[SuperCollider ] (http://supercollider.sourceforge.net/) version `3.6.6`

## Usage

- Run the standalone with `run.sh` script.
- Modify `init.scd` to customize.
- [Platypus ](http://sveinbjorn.org/platypus) can be used to convert the script based structure into a native OSX application.

--------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------